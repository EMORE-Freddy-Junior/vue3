/**
 * Created by aberezhnoy on 18/07/2017.
 */

ibglobal = {};
